###############################################################################
#                                                                             #
# YencaP software, LORIA-INRIA LORRAINE, MADYNES RESEARCH TEAM                #
# Copyright (C) 2005  Vincent CRIDLIG                                         #
#                                                                             #
# This library is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU Lesser General Public                  #
# License as published by the Free Software Foundation; either                #
# version 2.1 of the License, or (at your option) any later version.          #
#                                                                             #
# This library is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU           #
# Lesser General Public License for more details.                             #
#                                                                             #
# You should have received a copy of the GNU Lesser General Public            #
# License along with this library; if not, write to the Free Software         #
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   #
#                                                                             #
# Author Info:                                                                #
#   Name : Vincent CRIDLIG                                                    #
#   Email: Vincent.Cridlig@loria.fr                                           #
#                                                                             #
###############################################################################


#from Div import Div

#class DivMenu(Div):
#	"""
		
#	"""

#	def __init__(self):
#		self.id = "avmenu"
#		self.addContent("""
#<ul>
#<li><a href="http://madynes.loria.fr/ensuite/index.html">role de(activation)</a></li>
#<li><a href="http://madynes.loria.fr/ensuite/index.html">get-config</a></li>
#<li><a href="http://madynes.loria.fr/ensuite/yencap.html">get</a></li>
#<li><a href="http://madynes.loria.fr/ensuite/yencapMan.html">edit-config</a></li>
#<li><a href="http://madynes.loria.fr/ensuite/yencapCli.html">copy-config</a></li>
#<li><a href="http://madynes.loria.fr/ensuite/interfaces_mod.html">lock/unlock</a></li>
#<li><a href="http://madynes.loria.fr/ensuite/route_mod.html">kill-session</a></li>
#<li><a href="http://madynes.loria.fr/ensuite/bgp_mod.html">close-session</a></li>
#<i>Misc:</i>
#<li><a href="http://madynes.loria.fr/ensuite/news.html">News</a></li>
#</ul>
#""")
#	"""
		
